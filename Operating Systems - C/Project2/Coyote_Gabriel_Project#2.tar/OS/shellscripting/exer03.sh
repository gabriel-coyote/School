#!/bin/bash

# Display the number of files in your current directory
ls | wc -l
