#!/bin/bash

rm -rf *.out
rm -rf *.err
rm -rf *.tmp
echo "Deleted files with suffix out, err, tmp"
